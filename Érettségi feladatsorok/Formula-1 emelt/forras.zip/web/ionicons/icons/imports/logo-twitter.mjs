import icon from '../../dist/ionicons/svg/logo-twitter.svg'

export default /*#__PURE__*/ icon;