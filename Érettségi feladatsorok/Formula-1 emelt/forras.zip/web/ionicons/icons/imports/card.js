module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-card.svg'),
  md: require('../../dist/ionicons/svg/md-card.svg')
};