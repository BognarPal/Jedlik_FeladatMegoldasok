import icon from '../../dist/ionicons/svg/logo-octocat.svg'

export default /*#__PURE__*/ icon;