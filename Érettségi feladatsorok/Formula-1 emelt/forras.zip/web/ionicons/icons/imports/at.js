module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-at.svg'),
  md: require('../../dist/ionicons/svg/md-at.svg')
};