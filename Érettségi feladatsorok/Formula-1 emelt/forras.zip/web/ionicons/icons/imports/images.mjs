import ios from '../../dist/ionicons/svg/ios-images.svg';
import md from '../../dist/ionicons/svg/md-images.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};