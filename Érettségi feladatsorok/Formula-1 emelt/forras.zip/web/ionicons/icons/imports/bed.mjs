import ios from '../../dist/ionicons/svg/ios-bed.svg';
import md from '../../dist/ionicons/svg/md-bed.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};