module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-clipboard.svg'),
  md: require('../../dist/ionicons/svg/md-clipboard.svg')
};