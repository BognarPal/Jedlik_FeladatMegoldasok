import icon from '../../dist/ionicons/svg/logo-instagram.svg'

export default /*#__PURE__*/ icon;