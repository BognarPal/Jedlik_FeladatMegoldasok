module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-done-all.svg'),
  md: require('../../dist/ionicons/svg/md-done-all.svg')
};