module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-log-in.svg'),
  md: require('../../dist/ionicons/svg/md-log-in.svg')
};