import ios from '../../dist/ionicons/svg/ios-exit.svg';
import md from '../../dist/ionicons/svg/md-exit.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};