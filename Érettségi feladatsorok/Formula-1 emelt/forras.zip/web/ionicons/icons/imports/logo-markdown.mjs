import icon from '../../dist/ionicons/svg/logo-markdown.svg'

export default /*#__PURE__*/ icon;