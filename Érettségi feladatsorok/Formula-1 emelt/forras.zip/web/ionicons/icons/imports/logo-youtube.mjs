import icon from '../../dist/ionicons/svg/logo-youtube.svg'

export default /*#__PURE__*/ icon;