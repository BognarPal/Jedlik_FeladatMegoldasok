import ios from '../../dist/ionicons/svg/ios-download.svg';
import md from '../../dist/ionicons/svg/md-download.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};