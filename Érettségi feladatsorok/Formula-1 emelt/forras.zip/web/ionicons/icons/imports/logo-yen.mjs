import icon from '../../dist/ionicons/svg/logo-yen.svg'

export default /*#__PURE__*/ icon;