import ios from '../../dist/ionicons/svg/ios-contact.svg';
import md from '../../dist/ionicons/svg/md-contact.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};