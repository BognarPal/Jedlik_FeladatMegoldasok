import icon from '../../dist/ionicons/svg/logo-freebsd-devil.svg'

export default /*#__PURE__*/ icon;