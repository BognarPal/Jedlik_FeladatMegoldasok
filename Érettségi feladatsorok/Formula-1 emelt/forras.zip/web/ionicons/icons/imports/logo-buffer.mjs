import icon from '../../dist/ionicons/svg/logo-buffer.svg'

export default /*#__PURE__*/ icon;