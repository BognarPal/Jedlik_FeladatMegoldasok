import ios from '../../dist/ionicons/svg/ios-cloud.svg';
import md from '../../dist/ionicons/svg/md-cloud.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};