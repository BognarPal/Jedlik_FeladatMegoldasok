import ios from '../../dist/ionicons/svg/ios-list.svg';
import md from '../../dist/ionicons/svg/md-list.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};