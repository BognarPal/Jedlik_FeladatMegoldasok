module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-cloud.svg'),
  md: require('../../dist/ionicons/svg/md-cloud.svg')
};