module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-fitness.svg'),
  md: require('../../dist/ionicons/svg/md-fitness.svg')
};