module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-information.svg'),
  md: require('../../dist/ionicons/svg/md-information.svg')
};