import ios from '../../dist/ionicons/svg/ios-jet.svg';
import md from '../../dist/ionicons/svg/md-jet.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};