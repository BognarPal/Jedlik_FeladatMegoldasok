import icon from '../../dist/ionicons/svg/logo-googleplus.svg'

export default /*#__PURE__*/ icon;