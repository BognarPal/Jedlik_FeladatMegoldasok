import icon from '../../dist/ionicons/svg/logo-android.svg'

export default /*#__PURE__*/ icon;