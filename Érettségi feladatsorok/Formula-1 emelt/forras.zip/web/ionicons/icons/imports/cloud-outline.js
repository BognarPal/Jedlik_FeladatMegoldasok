module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-cloud-outline.svg'),
  md: require('../../dist/ionicons/svg/md-cloud-outline.svg')
};