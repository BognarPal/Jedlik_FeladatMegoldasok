import ios from '../../dist/ionicons/svg/ios-cloudy.svg';
import md from '../../dist/ionicons/svg/md-cloudy.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};