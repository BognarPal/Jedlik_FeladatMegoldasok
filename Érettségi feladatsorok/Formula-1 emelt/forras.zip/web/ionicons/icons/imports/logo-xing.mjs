import icon from '../../dist/ionicons/svg/logo-xing.svg'

export default /*#__PURE__*/ icon;