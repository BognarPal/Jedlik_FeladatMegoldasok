module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-boat.svg'),
  md: require('../../dist/ionicons/svg/md-boat.svg')
};