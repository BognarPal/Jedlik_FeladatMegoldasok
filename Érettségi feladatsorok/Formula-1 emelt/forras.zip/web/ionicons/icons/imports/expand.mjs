import ios from '../../dist/ionicons/svg/ios-expand.svg';
import md from '../../dist/ionicons/svg/md-expand.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};