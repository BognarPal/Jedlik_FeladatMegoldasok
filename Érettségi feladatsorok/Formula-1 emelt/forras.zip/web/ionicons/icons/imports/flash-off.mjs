import ios from '../../dist/ionicons/svg/ios-flash-off.svg';
import md from '../../dist/ionicons/svg/md-flash-off.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};