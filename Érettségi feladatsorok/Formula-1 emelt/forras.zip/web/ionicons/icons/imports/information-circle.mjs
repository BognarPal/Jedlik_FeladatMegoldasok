import ios from '../../dist/ionicons/svg/ios-information-circle.svg';
import md from '../../dist/ionicons/svg/md-information-circle.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};