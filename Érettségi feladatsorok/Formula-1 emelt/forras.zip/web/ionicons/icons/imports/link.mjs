import ios from '../../dist/ionicons/svg/ios-link.svg';
import md from '../../dist/ionicons/svg/md-link.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};