import ios from '../../dist/ionicons/svg/ios-arrow-forward.svg';
import md from '../../dist/ionicons/svg/md-arrow-forward.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};