import ios from '../../dist/ionicons/svg/ios-code-working.svg';
import md from '../../dist/ionicons/svg/md-code-working.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};