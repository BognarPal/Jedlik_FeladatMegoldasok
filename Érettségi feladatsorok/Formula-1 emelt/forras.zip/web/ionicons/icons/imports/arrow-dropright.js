module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-arrow-dropright.svg'),
  md: require('../../dist/ionicons/svg/md-arrow-dropright.svg')
};