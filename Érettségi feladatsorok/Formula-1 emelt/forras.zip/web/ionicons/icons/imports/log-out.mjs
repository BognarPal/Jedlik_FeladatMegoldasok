import ios from '../../dist/ionicons/svg/ios-log-out.svg';
import md from '../../dist/ionicons/svg/md-log-out.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};