import icon from '../../dist/ionicons/svg/logo-google.svg'

export default /*#__PURE__*/ icon;