import icon from '../../dist/ionicons/svg/logo-vk.svg'

export default /*#__PURE__*/ icon;