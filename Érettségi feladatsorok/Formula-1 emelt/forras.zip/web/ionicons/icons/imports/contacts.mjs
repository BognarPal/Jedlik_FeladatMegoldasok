import ios from '../../dist/ionicons/svg/ios-contacts.svg';
import md from '../../dist/ionicons/svg/md-contacts.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};