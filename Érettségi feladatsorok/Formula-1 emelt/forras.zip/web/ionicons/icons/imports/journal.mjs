import ios from '../../dist/ionicons/svg/ios-journal.svg';
import md from '../../dist/ionicons/svg/md-journal.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};