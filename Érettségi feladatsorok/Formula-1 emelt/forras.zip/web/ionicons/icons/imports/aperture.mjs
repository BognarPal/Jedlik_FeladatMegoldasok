import ios from '../../dist/ionicons/svg/ios-aperture.svg';
import md from '../../dist/ionicons/svg/md-aperture.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};