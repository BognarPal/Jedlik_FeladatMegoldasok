import ios from '../../dist/ionicons/svg/ios-book.svg';
import md from '../../dist/ionicons/svg/md-book.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};