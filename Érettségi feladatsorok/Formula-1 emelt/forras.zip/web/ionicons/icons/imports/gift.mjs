import ios from '../../dist/ionicons/svg/ios-gift.svg';
import md from '../../dist/ionicons/svg/md-gift.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};