import icon from '../../dist/ionicons/svg/logo-closed-captioning.svg'

export default /*#__PURE__*/ icon;