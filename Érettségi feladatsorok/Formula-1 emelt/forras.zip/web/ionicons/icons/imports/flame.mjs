import ios from '../../dist/ionicons/svg/ios-flame.svg';
import md from '../../dist/ionicons/svg/md-flame.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};