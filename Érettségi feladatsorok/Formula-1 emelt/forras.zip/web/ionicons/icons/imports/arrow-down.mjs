import ios from '../../dist/ionicons/svg/ios-arrow-down.svg';
import md from '../../dist/ionicons/svg/md-arrow-down.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};