import icon from '../../dist/ionicons/svg/logo-reddit.svg'

export default /*#__PURE__*/ icon;