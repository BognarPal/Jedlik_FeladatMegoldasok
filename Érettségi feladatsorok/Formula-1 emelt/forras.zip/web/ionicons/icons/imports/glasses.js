module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-glasses.svg'),
  md: require('../../dist/ionicons/svg/md-glasses.svg')
};