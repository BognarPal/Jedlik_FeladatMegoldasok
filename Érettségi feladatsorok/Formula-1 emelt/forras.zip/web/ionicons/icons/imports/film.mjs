import ios from '../../dist/ionicons/svg/ios-film.svg';
import md from '../../dist/ionicons/svg/md-film.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};