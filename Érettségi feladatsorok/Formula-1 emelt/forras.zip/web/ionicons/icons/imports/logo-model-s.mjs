import icon from '../../dist/ionicons/svg/logo-model-s.svg'

export default /*#__PURE__*/ icon;