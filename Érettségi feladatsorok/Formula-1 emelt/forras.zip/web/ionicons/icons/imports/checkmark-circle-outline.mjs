import ios from '../../dist/ionicons/svg/ios-checkmark-circle-outline.svg';
import md from '../../dist/ionicons/svg/md-checkmark-circle-outline.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};