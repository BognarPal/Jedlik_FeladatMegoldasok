import ios from '../../dist/ionicons/svg/ios-help-buoy.svg';
import md from '../../dist/ionicons/svg/md-help-buoy.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};