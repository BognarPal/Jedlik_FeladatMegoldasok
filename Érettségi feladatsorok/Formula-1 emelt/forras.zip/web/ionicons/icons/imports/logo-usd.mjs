import icon from '../../dist/ionicons/svg/logo-usd.svg'

export default /*#__PURE__*/ icon;