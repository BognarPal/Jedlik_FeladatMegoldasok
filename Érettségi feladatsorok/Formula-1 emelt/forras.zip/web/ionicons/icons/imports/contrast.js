module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-contrast.svg'),
  md: require('../../dist/ionicons/svg/md-contrast.svg')
};