import icon from '../../dist/ionicons/svg/logo-game-controller-a.svg'

export default /*#__PURE__*/ icon;