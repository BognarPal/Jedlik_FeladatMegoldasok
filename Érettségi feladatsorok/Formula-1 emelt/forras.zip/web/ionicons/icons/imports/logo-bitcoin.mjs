import icon from '../../dist/ionicons/svg/logo-bitcoin.svg'

export default /*#__PURE__*/ icon;