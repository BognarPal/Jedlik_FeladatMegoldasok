import ios from '../../dist/ionicons/svg/ios-arrow-dropdown-circle.svg';
import md from '../../dist/ionicons/svg/md-arrow-dropdown-circle.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};