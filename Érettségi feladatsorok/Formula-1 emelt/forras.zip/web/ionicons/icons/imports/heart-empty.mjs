import ios from '../../dist/ionicons/svg/ios-heart-empty.svg';
import md from '../../dist/ionicons/svg/md-heart-empty.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};