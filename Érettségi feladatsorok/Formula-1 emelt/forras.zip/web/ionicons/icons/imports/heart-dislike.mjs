import ios from '../../dist/ionicons/svg/ios-heart-dislike.svg';
import md from '../../dist/ionicons/svg/md-heart-dislike.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};