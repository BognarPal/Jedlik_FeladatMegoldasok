module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-log-out.svg'),
  md: require('../../dist/ionicons/svg/md-log-out.svg')
};