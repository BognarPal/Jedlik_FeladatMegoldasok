import ios from '../../dist/ionicons/svg/ios-compass.svg';
import md from '../../dist/ionicons/svg/md-compass.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};