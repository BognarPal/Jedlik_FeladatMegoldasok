import icon from '../../dist/ionicons/svg/logo-playstation.svg'

export default /*#__PURE__*/ icon;