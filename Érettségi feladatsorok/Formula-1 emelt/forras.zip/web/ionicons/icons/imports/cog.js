module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-cog.svg'),
  md: require('../../dist/ionicons/svg/md-cog.svg')
};