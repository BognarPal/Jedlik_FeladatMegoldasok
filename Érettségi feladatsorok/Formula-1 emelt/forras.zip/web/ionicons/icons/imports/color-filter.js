module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-color-filter.svg'),
  md: require('../../dist/ionicons/svg/md-color-filter.svg')
};