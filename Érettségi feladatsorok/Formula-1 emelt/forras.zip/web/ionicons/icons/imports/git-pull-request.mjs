import ios from '../../dist/ionicons/svg/ios-git-pull-request.svg';
import md from '../../dist/ionicons/svg/md-git-pull-request.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};