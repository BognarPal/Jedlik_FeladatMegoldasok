import ios from '../../dist/ionicons/svg/ios-git-merge.svg';
import md from '../../dist/ionicons/svg/md-git-merge.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};