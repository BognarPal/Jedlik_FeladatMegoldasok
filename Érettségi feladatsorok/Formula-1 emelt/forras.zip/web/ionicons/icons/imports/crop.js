module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-crop.svg'),
  md: require('../../dist/ionicons/svg/md-crop.svg')
};