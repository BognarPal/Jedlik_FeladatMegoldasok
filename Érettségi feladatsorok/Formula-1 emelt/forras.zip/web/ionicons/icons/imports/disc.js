module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-disc.svg'),
  md: require('../../dist/ionicons/svg/md-disc.svg')
};