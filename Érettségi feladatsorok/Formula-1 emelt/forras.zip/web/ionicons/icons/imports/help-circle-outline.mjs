import ios from '../../dist/ionicons/svg/ios-help-circle-outline.svg';
import md from '../../dist/ionicons/svg/md-help-circle-outline.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};