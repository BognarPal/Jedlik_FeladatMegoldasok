import ios from '../../dist/ionicons/svg/ios-list-box.svg';
import md from '../../dist/ionicons/svg/md-list-box.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};