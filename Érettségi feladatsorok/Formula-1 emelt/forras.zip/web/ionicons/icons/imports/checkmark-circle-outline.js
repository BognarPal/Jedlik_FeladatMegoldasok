module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-checkmark-circle-outline.svg'),
  md: require('../../dist/ionicons/svg/md-checkmark-circle-outline.svg')
};