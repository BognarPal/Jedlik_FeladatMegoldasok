import icon from '../../dist/ionicons/svg/logo-hackernews.svg'

export default /*#__PURE__*/ icon;