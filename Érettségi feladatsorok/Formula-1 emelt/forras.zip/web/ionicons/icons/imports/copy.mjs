import ios from '../../dist/ionicons/svg/ios-copy.svg';
import md from '../../dist/ionicons/svg/md-copy.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};