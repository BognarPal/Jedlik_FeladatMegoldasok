import ios from '../../dist/ionicons/svg/ios-code.svg';
import md from '../../dist/ionicons/svg/md-code.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};