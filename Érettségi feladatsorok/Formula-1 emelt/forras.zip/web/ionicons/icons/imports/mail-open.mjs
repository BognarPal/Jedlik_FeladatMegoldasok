import ios from '../../dist/ionicons/svg/ios-mail-open.svg';
import md from '../../dist/ionicons/svg/md-mail-open.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};