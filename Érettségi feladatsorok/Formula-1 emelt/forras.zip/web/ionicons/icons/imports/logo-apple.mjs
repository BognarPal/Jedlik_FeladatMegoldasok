import icon from '../../dist/ionicons/svg/logo-apple.svg'

export default /*#__PURE__*/ icon;