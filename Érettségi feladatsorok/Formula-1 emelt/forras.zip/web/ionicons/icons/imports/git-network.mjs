import ios from '../../dist/ionicons/svg/ios-git-network.svg';
import md from '../../dist/ionicons/svg/md-git-network.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};