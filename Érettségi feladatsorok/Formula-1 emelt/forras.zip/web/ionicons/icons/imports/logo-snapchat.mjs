import icon from '../../dist/ionicons/svg/logo-snapchat.svg'

export default /*#__PURE__*/ icon;