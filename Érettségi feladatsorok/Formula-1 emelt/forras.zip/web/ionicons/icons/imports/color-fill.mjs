import ios from '../../dist/ionicons/svg/ios-color-fill.svg';
import md from '../../dist/ionicons/svg/md-color-fill.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};