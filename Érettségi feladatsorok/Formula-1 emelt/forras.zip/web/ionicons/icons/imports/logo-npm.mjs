import icon from '../../dist/ionicons/svg/logo-npm.svg'

export default /*#__PURE__*/ icon;