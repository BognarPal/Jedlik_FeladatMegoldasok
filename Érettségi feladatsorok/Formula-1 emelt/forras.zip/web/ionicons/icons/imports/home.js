module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-home.svg'),
  md: require('../../dist/ionicons/svg/md-home.svg')
};