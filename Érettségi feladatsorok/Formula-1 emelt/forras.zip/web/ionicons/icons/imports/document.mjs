import ios from '../../dist/ionicons/svg/ios-document.svg';
import md from '../../dist/ionicons/svg/md-document.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};