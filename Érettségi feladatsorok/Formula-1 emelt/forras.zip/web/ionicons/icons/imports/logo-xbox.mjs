import icon from '../../dist/ionicons/svg/logo-xbox.svg'

export default /*#__PURE__*/ icon;