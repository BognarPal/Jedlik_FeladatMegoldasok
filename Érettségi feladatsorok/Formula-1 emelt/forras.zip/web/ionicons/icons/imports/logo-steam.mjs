import icon from '../../dist/ionicons/svg/logo-steam.svg'

export default /*#__PURE__*/ icon;