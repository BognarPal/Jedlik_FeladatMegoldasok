module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-ice-cream.svg'),
  md: require('../../dist/ionicons/svg/md-ice-cream.svg')
};