import ios from '../../dist/ionicons/svg/ios-leaf.svg';
import md from '../../dist/ionicons/svg/md-leaf.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};