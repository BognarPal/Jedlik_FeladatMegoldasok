module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-flash-off.svg'),
  md: require('../../dist/ionicons/svg/md-flash-off.svg')
};