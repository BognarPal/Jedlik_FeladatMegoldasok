module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-arrow-dropleft-circle.svg'),
  md: require('../../dist/ionicons/svg/md-arrow-dropleft-circle.svg')
};