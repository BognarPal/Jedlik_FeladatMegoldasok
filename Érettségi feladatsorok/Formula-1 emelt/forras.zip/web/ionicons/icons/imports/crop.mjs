import ios from '../../dist/ionicons/svg/ios-crop.svg';
import md from '../../dist/ionicons/svg/md-crop.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};