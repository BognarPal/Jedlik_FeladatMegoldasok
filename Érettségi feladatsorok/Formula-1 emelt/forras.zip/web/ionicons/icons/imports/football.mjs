import ios from '../../dist/ionicons/svg/ios-football.svg';
import md from '../../dist/ionicons/svg/md-football.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};