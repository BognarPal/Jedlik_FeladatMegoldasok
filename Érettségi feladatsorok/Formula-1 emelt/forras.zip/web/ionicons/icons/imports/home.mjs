import ios from '../../dist/ionicons/svg/ios-home.svg';
import md from '../../dist/ionicons/svg/md-home.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};