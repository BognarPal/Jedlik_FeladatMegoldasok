import ios from '../../dist/ionicons/svg/ios-code-download.svg';
import md from '../../dist/ionicons/svg/md-code-download.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};