import icon from '../../dist/ionicons/svg/logo-dribbble.svg'

export default /*#__PURE__*/ icon;