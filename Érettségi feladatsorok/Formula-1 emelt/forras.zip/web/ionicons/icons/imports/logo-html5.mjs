import icon from '../../dist/ionicons/svg/logo-html5.svg'

export default /*#__PURE__*/ icon;