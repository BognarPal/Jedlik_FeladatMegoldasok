module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-cube.svg'),
  md: require('../../dist/ionicons/svg/md-cube.svg')
};