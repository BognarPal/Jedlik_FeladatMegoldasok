module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-bus.svg'),
  md: require('../../dist/ionicons/svg/md-bus.svg')
};