import ios from '../../dist/ionicons/svg/ios-folder-open.svg';
import md from '../../dist/ionicons/svg/md-folder-open.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};