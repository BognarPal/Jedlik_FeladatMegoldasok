import ios from '../../dist/ionicons/svg/ios-folder.svg';
import md from '../../dist/ionicons/svg/md-folder.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};