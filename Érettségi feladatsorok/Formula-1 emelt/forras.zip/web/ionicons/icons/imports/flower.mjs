import ios from '../../dist/ionicons/svg/ios-flower.svg';
import md from '../../dist/ionicons/svg/md-flower.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};