import icon from '../../dist/ionicons/svg/logo-rss.svg'

export default /*#__PURE__*/ icon;