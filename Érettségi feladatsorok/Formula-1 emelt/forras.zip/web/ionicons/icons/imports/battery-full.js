module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-battery-full.svg'),
  md: require('../../dist/ionicons/svg/md-battery-full.svg')
};