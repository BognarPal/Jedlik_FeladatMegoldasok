module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-brush.svg'),
  md: require('../../dist/ionicons/svg/md-brush.svg')
};