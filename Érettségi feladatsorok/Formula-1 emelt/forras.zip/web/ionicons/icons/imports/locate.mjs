import ios from '../../dist/ionicons/svg/ios-locate.svg';
import md from '../../dist/ionicons/svg/md-locate.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};