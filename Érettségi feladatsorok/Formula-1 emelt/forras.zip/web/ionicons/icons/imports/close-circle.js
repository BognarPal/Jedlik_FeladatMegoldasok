module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-close-circle.svg'),
  md: require('../../dist/ionicons/svg/md-close-circle.svg')
};