module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-git-branch.svg'),
  md: require('../../dist/ionicons/svg/md-git-branch.svg')
};