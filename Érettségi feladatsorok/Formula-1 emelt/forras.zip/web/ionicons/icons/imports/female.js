module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-female.svg'),
  md: require('../../dist/ionicons/svg/md-female.svg')
};