import ios from '../../dist/ionicons/svg/ios-eye.svg';
import md from '../../dist/ionicons/svg/md-eye.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};