import ios from '../../dist/ionicons/svg/ios-arrow-dropleft-circle.svg';
import md from '../../dist/ionicons/svg/md-arrow-dropleft-circle.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};