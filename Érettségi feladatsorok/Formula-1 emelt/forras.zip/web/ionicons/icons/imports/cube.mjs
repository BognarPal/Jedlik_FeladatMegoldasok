import ios from '../../dist/ionicons/svg/ios-cube.svg';
import md from '../../dist/ionicons/svg/md-cube.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};