import ios from '../../dist/ionicons/svg/ios-camera.svg';
import md from '../../dist/ionicons/svg/md-camera.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};