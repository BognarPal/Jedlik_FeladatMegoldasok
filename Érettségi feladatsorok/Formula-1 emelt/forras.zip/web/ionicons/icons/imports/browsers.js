module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-browsers.svg'),
  md: require('../../dist/ionicons/svg/md-browsers.svg')
};