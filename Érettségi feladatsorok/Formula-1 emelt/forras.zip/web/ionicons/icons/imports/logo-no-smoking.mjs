import icon from '../../dist/ionicons/svg/logo-no-smoking.svg'

export default /*#__PURE__*/ icon;