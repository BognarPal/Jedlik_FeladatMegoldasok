import icon from '../../dist/ionicons/svg/logo-slack.svg'

export default /*#__PURE__*/ icon;