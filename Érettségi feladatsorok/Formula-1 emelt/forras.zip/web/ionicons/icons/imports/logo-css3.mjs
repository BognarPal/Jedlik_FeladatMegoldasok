import icon from '../../dist/ionicons/svg/logo-css3.svg'

export default /*#__PURE__*/ icon;