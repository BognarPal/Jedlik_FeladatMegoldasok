import icon from '../../dist/ionicons/svg/logo-foursquare.svg'

export default /*#__PURE__*/ icon;