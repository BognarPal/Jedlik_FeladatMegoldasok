module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-magnet.svg'),
  md: require('../../dist/ionicons/svg/md-magnet.svg')
};