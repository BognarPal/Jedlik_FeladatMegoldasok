module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-git-commit.svg'),
  md: require('../../dist/ionicons/svg/md-git-commit.svg')
};