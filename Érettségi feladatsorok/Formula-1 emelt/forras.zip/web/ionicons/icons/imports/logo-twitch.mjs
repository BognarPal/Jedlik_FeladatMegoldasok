import icon from '../../dist/ionicons/svg/logo-twitch.svg'

export default /*#__PURE__*/ icon;