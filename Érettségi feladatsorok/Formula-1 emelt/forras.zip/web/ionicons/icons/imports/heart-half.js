module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-heart-half.svg'),
  md: require('../../dist/ionicons/svg/md-heart-half.svg')
};