import ios from '../../dist/ionicons/svg/ios-card.svg';
import md from '../../dist/ionicons/svg/md-card.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};