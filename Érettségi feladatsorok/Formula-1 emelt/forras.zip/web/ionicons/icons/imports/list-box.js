module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-list-box.svg'),
  md: require('../../dist/ionicons/svg/md-list-box.svg')
};