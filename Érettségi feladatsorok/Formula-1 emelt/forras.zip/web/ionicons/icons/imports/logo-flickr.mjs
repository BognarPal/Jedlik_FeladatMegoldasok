import icon from '../../dist/ionicons/svg/logo-flickr.svg'

export default /*#__PURE__*/ icon;