import icon from '../../dist/ionicons/svg/logo-javascript.svg'

export default /*#__PURE__*/ icon;