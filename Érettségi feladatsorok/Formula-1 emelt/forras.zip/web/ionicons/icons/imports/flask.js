module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-flask.svg'),
  md: require('../../dist/ionicons/svg/md-flask.svg')
};