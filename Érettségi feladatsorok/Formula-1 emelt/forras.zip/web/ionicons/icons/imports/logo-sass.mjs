import icon from '../../dist/ionicons/svg/logo-sass.svg'

export default /*#__PURE__*/ icon;