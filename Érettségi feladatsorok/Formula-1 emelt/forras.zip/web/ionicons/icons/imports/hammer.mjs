import ios from '../../dist/ionicons/svg/ios-hammer.svg';
import md from '../../dist/ionicons/svg/md-hammer.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};