module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-easel.svg'),
  md: require('../../dist/ionicons/svg/md-easel.svg')
};