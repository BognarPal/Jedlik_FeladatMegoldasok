module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-images.svg'),
  md: require('../../dist/ionicons/svg/md-images.svg')
};