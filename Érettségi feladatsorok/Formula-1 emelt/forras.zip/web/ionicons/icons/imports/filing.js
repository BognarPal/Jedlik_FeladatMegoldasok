module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-filing.svg'),
  md: require('../../dist/ionicons/svg/md-filing.svg')
};