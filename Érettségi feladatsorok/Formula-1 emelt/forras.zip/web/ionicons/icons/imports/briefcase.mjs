import ios from '../../dist/ionicons/svg/ios-briefcase.svg';
import md from '../../dist/ionicons/svg/md-briefcase.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};