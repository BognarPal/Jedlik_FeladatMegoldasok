module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-checkmark.svg'),
  md: require('../../dist/ionicons/svg/md-checkmark.svg')
};