import ios from '../../dist/ionicons/svg/ios-filing.svg';
import md from '../../dist/ionicons/svg/md-filing.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};