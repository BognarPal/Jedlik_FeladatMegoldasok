module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-copy.svg'),
  md: require('../../dist/ionicons/svg/md-copy.svg')
};