import ios from '../../dist/ionicons/svg/ios-log-in.svg';
import md from '../../dist/ionicons/svg/md-log-in.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};