import icon from '../../dist/ionicons/svg/logo-vimeo.svg'

export default /*#__PURE__*/ icon;