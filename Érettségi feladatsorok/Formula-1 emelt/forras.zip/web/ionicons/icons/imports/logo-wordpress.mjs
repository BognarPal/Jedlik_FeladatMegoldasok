import icon from '../../dist/ionicons/svg/logo-wordpress.svg'

export default /*#__PURE__*/ icon;