import icon from '../../dist/ionicons/svg/logo-codepen.svg'

export default /*#__PURE__*/ icon;