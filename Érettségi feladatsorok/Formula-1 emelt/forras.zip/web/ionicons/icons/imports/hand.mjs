import ios from '../../dist/ionicons/svg/ios-hand.svg';
import md from '../../dist/ionicons/svg/md-hand.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};