import ios from '../../dist/ionicons/svg/ios-bluetooth.svg';
import md from '../../dist/ionicons/svg/md-bluetooth.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};