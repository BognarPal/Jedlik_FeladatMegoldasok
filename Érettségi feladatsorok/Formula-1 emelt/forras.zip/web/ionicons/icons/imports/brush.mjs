import ios from '../../dist/ionicons/svg/ios-brush.svg';
import md from '../../dist/ionicons/svg/md-brush.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};