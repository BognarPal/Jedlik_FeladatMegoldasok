import icon from '../../dist/ionicons/svg/logo-yahoo.svg'

export default /*#__PURE__*/ icon;