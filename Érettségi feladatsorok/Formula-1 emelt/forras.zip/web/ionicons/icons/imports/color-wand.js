module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-color-wand.svg'),
  md: require('../../dist/ionicons/svg/md-color-wand.svg')
};