module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-help-circle-outline.svg'),
  md: require('../../dist/ionicons/svg/md-help-circle-outline.svg')
};