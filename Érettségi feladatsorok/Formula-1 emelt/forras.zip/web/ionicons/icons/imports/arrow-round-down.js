module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-arrow-round-down.svg'),
  md: require('../../dist/ionicons/svg/md-arrow-round-down.svg')
};