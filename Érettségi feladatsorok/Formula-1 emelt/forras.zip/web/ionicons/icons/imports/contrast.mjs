import ios from '../../dist/ionicons/svg/ios-contrast.svg';
import md from '../../dist/ionicons/svg/md-contrast.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};