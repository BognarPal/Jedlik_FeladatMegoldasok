import icon from '../../dist/ionicons/svg/logo-ionic.svg'

export default /*#__PURE__*/ icon;