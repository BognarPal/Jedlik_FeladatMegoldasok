module.exports = /*#__PURE__*/ {
  ios: require('../../dist/ionicons/svg/ios-egg.svg'),
  md: require('../../dist/ionicons/svg/md-egg.svg')
};