import ios from '../../dist/ionicons/svg/ios-flash.svg';
import md from '../../dist/ionicons/svg/md-flash.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};