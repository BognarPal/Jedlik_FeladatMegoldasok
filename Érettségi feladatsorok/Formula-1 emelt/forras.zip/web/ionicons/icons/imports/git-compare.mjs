import ios from '../../dist/ionicons/svg/ios-git-compare.svg';
import md from '../../dist/ionicons/svg/md-git-compare.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};