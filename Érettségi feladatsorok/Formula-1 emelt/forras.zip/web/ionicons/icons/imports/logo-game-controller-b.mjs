import icon from '../../dist/ionicons/svg/logo-game-controller-b.svg'

export default /*#__PURE__*/ icon;