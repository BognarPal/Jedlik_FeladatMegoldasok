import ios from '../../dist/ionicons/svg/ios-add.svg';
import md from '../../dist/ionicons/svg/md-add.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};