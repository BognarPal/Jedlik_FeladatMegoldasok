import icon from '../../dist/ionicons/svg/logo-python.svg'

export default /*#__PURE__*/ icon;