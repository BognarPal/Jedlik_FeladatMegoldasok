import ios from '../../dist/ionicons/svg/ios-arrow-round-back.svg';
import md from '../../dist/ionicons/svg/md-arrow-round-back.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};