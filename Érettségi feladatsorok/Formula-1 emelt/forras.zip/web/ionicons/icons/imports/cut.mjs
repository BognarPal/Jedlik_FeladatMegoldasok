import ios from '../../dist/ionicons/svg/ios-cut.svg';
import md from '../../dist/ionicons/svg/md-cut.svg';

export default /*#__PURE__*/ {
  ios: ios,
  md: md
};